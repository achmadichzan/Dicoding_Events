package com.achmadichzan.dicodingevents.presentation.screen.event_detail

import androidx.compose.runtime.Composable
import com.achmadichzan.dicodingevents.presentation.screen.event_list.EventViewModel

@Composable
fun StateDetailScreen(viewModel: EventViewModel) {

}